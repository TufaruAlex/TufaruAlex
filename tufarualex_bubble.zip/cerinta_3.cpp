//Sortarea descrescatoare
#include<iostream>
#include<fstream>
using namespace std;
int n;
int v[100];
int main(){
fstream f;
f.open("input.dat",ios::in);
f>>n;
int copie=n;
for(int i=1;i<=n;i++){
    f>>v[i];
}
int gata=0;
while(gata==0){
    gata=1;
    for(int i=1;i<=n-1;i++){
        if(v[i]<v[i+1]){
            swap(v[i],v[i+1]);
            gata=0;
        }
    }
}
n=copie;
for(int i=1;i<=n;i++){
    cout<<v[i]<<" ";
}
return 0;
}
