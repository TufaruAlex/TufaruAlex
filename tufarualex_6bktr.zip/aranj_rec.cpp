//aranjamente recursiv
#include<iostream>
using namespace std;
int ST[100];
int n,k;
int vf;

class stack {
public :
    stack(){
        top=0;
    }
    int push(int value){
        if (top<maxsize){
                top++;
                S[top]=value;
                return 1;
        }
        return 0;
        }
        int pop(int *old){
            if (isempty()){
                    return 0;
            }
            *old=S[top];top--;
            return 1;
            }

        int whathight(){
            return top;
            }
        int isempty(){
            return (top<1);
            }
private :
    int top;
    int S[100];
    int maxsize=100;
};
stack somestack;

int init(stack Stack){
    Stack.push(0);
}

int tipar(stack Stack){
cout<<endl;
for(int i=1;i<=Stack.whathight();i++){
        int j=0;
        Stack.pop(&j);
        cout<<j<<" ";
        }
}

int solutie(stack Stack){
if (Stack.whathight()==(k+1)) return 1;
else return 0;
}

int succesor(stack Stack){
int j=0;
Stack.pop(&j);
if (j<n){
        Stack.push(j+1);return 1;
}
else return 0;
}

int valid(stack Stack){
int j=0;
Stack.pop(&j);
if (Stack.whathight()==1)  return 1;
else{
        for(int i=1;i<Stack.whathight();i++){
            int k=0;
            Stack.pop(&k);
            if (k==j) return 0;
}
        return 1;
}
}

int BKTR_rec(stack Stack)
{
if (solutie(Stack)){tipar(Stack);}
while (succesor(Stack))
    {
      if ( valid(Stack) ) {
            vf++;
            init(Stack);
            BKTR_rec(Stack);
                               }
    }
 return 0; }

 int main()
 {
cout<<"n=";cin>>n;
cout<<"k=";cin>>k;
 vf==1;
 init(somestack);
 BKTR_rec(somestack);
 }
